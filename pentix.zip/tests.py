#!/usr/bin/python3
# -*- coding: utf-8 -*-

import unittest
from game import Game


class BaseLogicTests(unittest.TestCase):

    def test_create_game(self):
        pass


if __name__ == '__main__':
    unittest.main()
