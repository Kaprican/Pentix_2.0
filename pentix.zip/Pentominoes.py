class Pentominoes(object):

    NoShape = 0
    FShape = 1
    CShape = 2
    LineShape = 3
    LShape = 4
    VShape = 5
    PShape = 6
    TShape = 7
    ZShape = 8
    WShape = 9
    XShape = 10
    YShape = 11
    NShape = 12
